MIT License
This project is licensed under the terms of the MIT license.