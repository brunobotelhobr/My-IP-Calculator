"""Does implementation of the app."""
